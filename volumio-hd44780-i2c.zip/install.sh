#!/bin/bash
echo "Installing dependencies for volumio-hd44780-i2c"
npm install --prefix /data/plugins/miscellanea/volumio-hd44780-i2c
exit 0
