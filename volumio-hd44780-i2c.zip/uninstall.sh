#!/bin/bash
echo "Uninstalling volumio-hd44780-i2c"
exit 0
